export const SHOP_CONFIG = {
  name: 'Zamzam Mobile Center',
  shortName: 'Zamzam',
  subTitle: 'Mobile & Accessories',
  fullTitle: 'Zamzam Mobile Center',
  address: 'Zamzam Mobile Center',
  phone: '',
  logoUrl: '/favicon.svg',
  theme: {
    primaryBg: '#1B4332',
    accentEmerald: '#10B981',
  },
};
